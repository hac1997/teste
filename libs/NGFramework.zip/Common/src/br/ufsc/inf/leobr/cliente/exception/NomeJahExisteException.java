package br.ufsc.inf.leobr.cliente.exception;

public class NomeJahExisteException {

}
